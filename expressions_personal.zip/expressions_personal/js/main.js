/**
 * Created by seanpro on 9/10/14.
 */
//sean edwards
//9/10/14
//wpf section 0
//expression person page


alert("I own a 1999 honda civic and she is the love of my life");

var yourYear=prompt("what year is your car?");
var yourcar=prompt("what type of car do you own?");
var PrettyInPink=prompt("is it ugly or pretty?");


alert("I bet my honda is nicer than your " + PrettyInPink +" "+ yourYear +" "+ yourcar+" Lol");


var maintenance=["oil change","car wash","tires","windshield wipers"];
var oilChange=21.99; //price of oil change
var carWash=23.99;  //car wash price
var tires=34.99; //new tires price
var windshieldWipers=25.00; //price for new wipers
var totalAmountEachMonth=oilChange+carWash+tires+windshieldWipers;
var carType="I own a 99 honda civic and yes she is the love of my life";

console.log("every month i spend a total of " +totalAmountEachMonth+ " on my car maintenance");
console.log("my maintenance items include " +maintenance+ " this is also my array");
console.log("My string is" +carType);
console.log("my variables include oilChange, carWash, windshieldWipers, tires,and also totalAmountEachMonth which is the calculation of them all added together.");
